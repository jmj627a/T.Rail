﻿
public interface IState
{
    void on_enter();
    void on_exit();
}
